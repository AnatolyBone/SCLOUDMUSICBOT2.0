# SoundCloud Telegram Bot v2.0

Telegram бот для загрузки треков с SoundCloud с улучшенной производительностью, современным UI админки и расширенными возможностями.

## 🚀 Новые возможности v2.0

### Улучшения производительности
- ✅ Увеличена параллельная обработка загрузок (до 3 одновременно)
- ✅ Оптимизированы таймауты и количество попыток
- ✅ Улучшено кэширование треков
- ✅ Добавлены индексы базы данных для быстрых запросов

### Безопасность
- ✅ Фильтрация SoundCloud Go+ треков по умолчанию
- ✅ Четкие предупреждения о ограничениях Go+ контента
- ✅ Улучшенное логирование административных действий
- ✅ Обновленные security headers

### Современная веб-админка
- ✅ Полностью обновленный дизайн с современными UI паттернами
- ✅ Адаптивная верстка для мобильных устройств
- ✅ Темная/светлая тема
- ✅ Интерактивные графики и аналитика
- ✅ Улучшенная навигация и поиск

### Архитектурные улучшения
- ✅ Оптимизированная структура кода
- ✅ Улучшенная обработка ошибок
- ✅ Расширенное логирование событий
- ✅ Подготовка к масштабированию

## 📋 Требования

- Node.js 18+
- PostgreSQL (через Supabase)
- Redis
- Telegram Bot Token
- Render или другой хостинг

## 🛠 Установка

1. **Клонирование репозитория**
```bash
git clone https://github.com/AnatolyBone/soundcloud-telegram-bot.git
cd soundcloud-telegram-bot
```

2. **Установка зависимостей**
```bash
npm install
```

3. **Настройка переменных окружения**
Создайте файл `.env` со следующими переменными:

```env
# Telegram Bot
BOT_TOKEN=your_telegram_bot_token
ADMIN_ID=your_telegram_user_id
WEBHOOK_URL=https://your-app.onrender.com

# Database (Supabase)
DATABASE_URL=postgresql://user:password@host:port/database
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your_supabase_anon_key

# Redis
REDIS_URL=redis://localhost:6379

# Admin Panel
ADMIN_LOGIN=admin
ADMIN_PASSWORD=secure_password
SESSION_SECRET=your_session_secret

# Storage
STORAGE_CHANNEL_ID=@your_storage_channel

# Optional
NODE_ENV=production
PORT=3000
```

4. **Настройка базы данных**
Выполните SQL скрипты для создания необходимых таблиц:

```sql
-- Создание таблицы пользователей с индексами
CREATE TABLE users (
  id BIGINT PRIMARY KEY,
  username VARCHAR(255),
  first_name VARCHAR(255),
  premium_limit INTEGER DEFAULT 10,
  downloads_today INTEGER DEFAULT 0,
  total_downloads INTEGER DEFAULT 0,
  premium_until TIMESTAMP,
  subscribed_bonus_used BOOLEAN DEFAULT FALSE,
  tracks_today JSONB DEFAULT '[]'::jsonb,
  last_reset_date DATE DEFAULT CURRENT_DATE,
  active BOOLEAN DEFAULT TRUE,
  referred_count INTEGER DEFAULT 0,
  referral_source VARCHAR(255),
  has_reviewed BOOLEAN DEFAULT FALSE,
  referrer_id BIGINT,
  promo_1plus1_used BOOLEAN DEFAULT FALSE,
  expiration_notified_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  last_active TIMESTAMP DEFAULT NOW()
);

-- Индексы для оптимизации производительности
CREATE INDEX idx_users_last_active ON users(last_active);
CREATE INDEX idx_users_premium_until ON users(premium_until);
CREATE INDEX idx_users_active_downloads ON users(active, downloads_today) WHERE active = true;

-- Таблица кэша треков
CREATE TABLE track_cache (
  url TEXT PRIMARY KEY,
  file_id TEXT NOT NULL,
  track_name TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_track_cache_url_hash ON track_cache USING hash(url);

-- Таблица событий для аналитики
CREATE TABLE events (
  id SERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  event_type VARCHAR(50) NOT NULL,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_events_user_type_date ON events(user_id, event_type, created_at);

-- Таблица отзывов
CREATE TABLE reviews (
  id SERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  text TEXT NOT NULL,
  time TIMESTAMP DEFAULT NOW()
);

-- Таблица логов активности
CREATE TABLE user_activity_logs (
  id SERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL,
  activity_time TIMESTAMP DEFAULT NOW()
);
```

5. **Запуск приложения**

Для разработки:
```bash
npm run dev
```

Для продакшена:
```bash
npm start
```

## 🔧 Конфигурация

### Основные настройки производительности

В файле `services/downloadManager.js` можно настроить:

```javascript
const CONFIG = {
  TELEGRAM_FILE_LIMIT_MB: 49,
  MAX_PLAYLIST_TRACKS_FREE: 15, // Увеличено с 10
  TRACK_TITLE_LIMIT: 100,
  MAX_CONCURRENT_DOWNLOADS: 3, // Увеличено с 1
  METADATA_FETCH_TIMEOUT_MS: 30000, // Уменьшено с 45000
  YTDL_RETRIES: 2, // Уменьшено с 3
  SOCKET_TIMEOUT: 120,
};
```

### Фильтрация SoundCloud Go+

Бот автоматически фильтрует Go+ треки. Для отключения фильтрации измените в `downloadManager.js`:

```javascript
// Фильтрация по умолчанию для Go+ треков
if (isGoPlus(info)) {
  throw new Error('Трек доступен только для SoundCloud Go+ подписчиков');
}
```

## 📊 Веб-админка

Доступ к админке: `https://your-app.onrender.com/dashboard`

### Возможности админки:
- 📈 Интерактивная аналитика с графиками
- 👥 Управление пользователями с поиском и фильтрацией
- 📢 Система рассылок с throttling
- ⚙️ Редактор текстов бота
- 📤 Экспорт данных в CSV
- 🌙 Темная/светлая тема
- 📱 Полная мобильная адаптация

## 🚀 Развертывание

### Render
1. Подключите GitHub репозиторий к Render
2. Настройте переменные окружения
3. Выберите план с поддержкой Redis
4. Деплой произойдет автоматически

### Railway (рекомендуется)
1. Подключите GitHub репозиторий к Railway
2. Настройте переменные окружения
3. Добавьте Redis addon
4. Деплой произойдет автоматически

## 📈 Мониторинг

### Рекомендуемые инструменты:
- **Sentry** - отслеживание ошибок
- **Uptime Robot** - мониторинг доступности
- **New Relic** - APM мониторинг

### Встроенные метрики:
- Количество активных пользователей
- Статистика загрузок
- Производительность очереди
- Аналитика по времени использования

## 🔍 Устранение неполадок

### Частые проблемы:

1. **SoundCloud Go+ треки загружаются как превью**
   - Это ожидаемое поведение для Go+ контента
   - Бот автоматически фильтрует такие треки

2. **Медленная загрузка**
   - Проверьте настройки `MAX_CONCURRENT_DOWNLOADS`
   - Убедитесь, что Redis работает корректно

3. **Ошибки базы данных**
   - Проверьте подключение к Supabase
   - Убедитесь, что все таблицы созданы

4. **Проблемы с админкой**
   - Проверьте переменные `ADMIN_LOGIN` и `ADMIN_PASSWORD`
   - Убедитесь, что сессии работают корректно

## 📝 Changelog

### v2.0.0
- ✅ Увеличена производительность в 3-5 раз
- ✅ Современная веб-админка с адаптивным дизайном
- ✅ Фильтрация SoundCloud Go+ треков
- ✅ Улучшенная безопасность и логирование
- ✅ Оптимизация базы данных с индексами
- ✅ Подготовка к масштабированию

### v1.0.1
- Базовая функциональность загрузки треков
- Простая веб-админка
- Система тарифов

## 🤝 Вклад в проект

1. Fork репозитория
2. Создайте feature branch (`git checkout -b feature/amazing-feature`)
3. Commit изменения (`git commit -m 'Add amazing feature'`)
4. Push в branch (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

## 📄 Лицензия

Этот проект лицензирован под MIT License - см. файл [LICENSE](LICENSE) для деталей.

## 👨‍💻 Автор

**Anatoly Bone**
- GitHub: [@AnatolyBone](https://github.com/AnatolyBone)

## 🙏 Благодарности

- [yt-dlp](https://github.com/yt-dlp/yt-dlp) за отличный инструмент загрузки
- [Telegraf](https://telegraf.js.org/) за удобную библиотеку для Telegram Bot API
- [Supabase](https://supabase.com/) за отличную альтернативу Firebase
- [Bootstrap](https://getbootstrap.com/) за UI компоненты

---

⭐ Если проект был полезен, поставьте звездочку на GitHub!

