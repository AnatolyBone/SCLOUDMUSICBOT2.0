document.addEventListener("DOMContentLoaded", function() {
  // Автоматическое скрытие уведомлений
  document.querySelectorAll("[data-autohide]").forEach(function(alert) {
    setTimeout(function() {
      alert.classList.remove("show");
      alert.classList.add("fade");
      setTimeout(function() {
        alert.remove();
      }, 150);
    }, 3000);
  });

  // Переключение темы
  const themeToggle = document.getElementById("themeToggle");
  if (themeToggle) {
    function setTheme(theme) {
      document.documentElement.setAttribute("data-theme", theme);
      localStorage.setItem("theme", theme);
      themeToggle.innerHTML = theme === "dark" ? 
        `<i class="bi bi-sun"></i>` : 
        `<i class="bi bi-moon"></i>`;
    }

    themeToggle.addEventListener("click", function() {
      const currentTheme = localStorage.getItem("theme") || "light";
      setTheme(currentTheme === "light" ? "dark" : "light");
    });

    // Установить тему при загрузке страницы
    const savedTheme = localStorage.getItem("theme") || "light";
    setTheme(savedTheme);
  }

  // Обработка выбора периода на дашборде
  const rangeSelect = document.getElementById("rangeSelect");
  const periodInput = document.getElementById("periodInput");
  const filterForm = document.getElementById("filterForm");

  if (rangeSelect && periodInput && filterForm) {
    rangeSelect.value = periodInput.value;
    rangeSelect.addEventListener("change", function() {
      periodInput.value = this.value;
      filterForm.submit();
    });
  }

  // Обработка поиска пользователей
  const userSearchInput = document.getElementById("userSearchInput");
  const userSearchForm = document.getElementById("userSearchForm");
  if (userSearchInput && userSearchForm) {
    userSearchInput.addEventListener("keypress", function(event) {
      if (event.key === "Enter") {
        event.preventDefault();
        userSearchForm.submit();
      }
    });
  }

  // Toast уведомления
  window.showToast = function(message, type = "success") {
    const toastContainer = document.getElementById("toastContainer");
    if (!toastContainer) {
      console.warn("Toast container not found");
      return;
    }

    const toast = document.createElement("div");
    toast.className = `toast align-items-center text-white bg-" + type + " border-0`;
    toast.setAttribute("role", "alert");
    toast.setAttribute("aria-live", "assertive");
    toast.setAttribute("aria-atomic", "true");
    toast.innerHTML = `
      <div class="d-flex">
        <div class="toast-body">
          ${message}
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    `;

    toastContainer.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
  };

  // Пример использования (можно удалить после интеграции)
  // showToast("Привет, это тестовое уведомление!", "info");
});


